You'll need to change the database connection strings present in Includes/Connection_inc.asp to view this example.
