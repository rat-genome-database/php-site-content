<?php 
$dsn="Northwind";
$username="sa";
$password="sa";
?>