<?php
	//Include connection and colors file
	include '../Connection_ini.php';
	include '../FC_Colors.php';
	
	//Connect to the ODBC Source
	$sqlconnect=odbc_connect($dsn,$username,$password);
	
	//oRs		- Recordset object	
	//strSQL		- String variable to contain the SQL query
	//intCounter - Numeric value to keep a track of number of records	
	//intYear	- Numeric value to keep index of year
	
	//strXMLData - String variable to contain the entire XML data document for the chart
	//strCategories - String variable to store the <categories> element and it's child <category> elements.
	//strAmountDS - String variable to store the amount <dataset>
	//strQuantityDS - String variable to store Quantity dataset
	
	//Initialize the <graph> element	
	$strXMLData = "<graph PYAxisName='Amount' SYAxisName='Quantity' showvalues='0' rotateNames='0' showAnchors='1' decimalPrecision='2' limitsDecimalPrecision='0' divLineDecimalPrecision='0' hoverCapSepChar=' ' showShadow='0' lineThickness='3'>" . chr(13);
	
	//Initiate <categories> element
	$strCategories = "<categories>" . chr(13);
	//Initialize the amount and quantity dataset	
	$strAmountDS = "<dataset seriesname='' showValue='1' color='" . $strColor[0] . "' numberPrefix='$' >" . chr(13);	
	$strQuantityDS = "<dataset seriesname='' showValue='1' color='" . $strColor[3] . "' parentYAxis='S' numberSuffix=' pcs.' anchorSides='12' anchorRadius='3' anchorBorderColor='" . $strColor[3] . "'>" . chr(13);

	$strCategories = "<categories>" . chr(13);
	$strDataSet = "";
	$intCounter=1;

	//Generate the query to get a list of unique years
	$strSQL="SELECT TOP 5 CustomerName, SUM(ExtendedPrice) As Total, SUM(Quantity) As Quantity, SUM(Discount*ExtendedPrice) As Discount FROM Invoices WHERE YEAR(OrderDate)=" . $_GET["year"] . " GROUP BY CustomerName ORDER BY SUM(ExtendedPrice) DESC";

	//Execute
	$oRs=odbc_exec($sqlconnect, $strSQL);
	//Initialize counter to 0
	$intCounter=0;
	
	//Iterate through each year to get the data for that year
	while(odbc_fetch_row($oRs))
	{
		
		//Generate the <category> element
		$strCategories = $strCategories . "<category name='" . Substr(odbc_result($oRs,"CustomerName"), 0,5) . "...' hoverText='" . odbc_result($oRs,"CustomerName") . "'/>" . chr(13);
		//Generate the set element for both amount and quantity dataset
		$strAmountDS = $strAmountDS . "<set value='" . odbc_result($oRs,"Total") . "' />" . chr(13);
		$strQuantityDS = $strQuantityDS . "<set value='" . odbc_result($oRs,"Quantity") . "' />" . chr(13);
		//Increment the counter
		$intCounter=$intCounter + 1;
	}
	//Close the category and dataset elements
	$strCategories = $strCategories . "</categories>" . chr(13);
	$strAmountDS = $strAmountDS . "</dataset>" . chr(13);
	$strQuantityDS = $strQuantityDS . "</dataset>" . chr(13);
	//Generate the XML document by concatenating the strings we've generated. Also, close the <graph> element.
	$strXMLData = $strXMLData . $strCategories . $strAmountDS. $strQuantityDS . "</graph>";

	//Write the XML data to output stream
	echo($strXMLData); 
?>