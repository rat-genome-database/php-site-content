vti_encoding:SR|utf8-nl
vti_author:SR|IUSR_SYSTEM
vti_modifiedby:SR|IUSR_SYSTEM
vti_timecreated:TR|07 Mar 2005 08:13:51 -0000
vti_timelastmodified:TR|07 Mar 2005 10:55:58 -0000
vti_filesize:IR|3099
vti_extenderversion:SR|4.0.2.8912
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|07 Mar 2005 10:55:49 -0000
vti_cacheddtm:TX|07 Mar 2005 10:55:50 -0000
