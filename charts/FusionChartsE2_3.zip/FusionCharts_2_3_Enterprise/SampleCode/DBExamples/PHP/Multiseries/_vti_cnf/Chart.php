vti_encoding:SR|utf8-nl
vti_author:SR|IUSR_SYSTEM
vti_modifiedby:SR|IUSR_SYSTEM
vti_timecreated:TR|07 Mar 2005 08:13:52 -0000
vti_timelastmodified:TR|07 Mar 2005 09:19:56 -0000
vti_filesize:IR|1485
vti_extenderversion:SR|4.0.2.8912
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|07 Mar 2005 08:45:10 -0000
vti_cacheddtm:TX|07 Mar 2005 08:44:50 -0000
