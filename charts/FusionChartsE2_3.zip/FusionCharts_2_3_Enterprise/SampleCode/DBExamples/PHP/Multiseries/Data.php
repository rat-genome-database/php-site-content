<?php
	//Include connection and colors file
	include '../Connection_ini.php';
	include '../FC_Colors.php';
	
	//Connect to the ODBC Source
	$sqlconnect=odbc_connect($dsn,$username,$password);
	
	//oRs		- Recordset object
	//oRsYears	- To store the list of years
	//strSQL		- String variable to contain the SQL query
	//intCounter - Numeric value to keep a track of number of records	
	//intYear	- Numeric value to keep index of year
	
	//strXMLData - String variable to contain the entire XML data document for the chart
	//strCategories - String variable to store the <categories> element and it's child <category> elements.
	//strDataSet - String variable to store the <dataset> and <data>	
	
	$strXMLData = "<graph caption='Country Comparison' shownames='1' showvalues='0' decimalPrecision='0' numberPrefix='$'>" . chr(13);
	$strCategories = "<categories><category name='Austria' /><category name='Brazil' /><category name='France' /><category name='Germany' /><category name='USA' /></categories>" . chr(13);
	$strDataSet = "";
	$intCounter=1;

	//Generate the query to get a list of unique years
	$strSQL="SELECT DISTINCT YEAR(OrderDate) As Year FROM Orders ORDER BY 1";

	//Get the list of years
	$oRsYears=odbc_exec($sqlconnect, $strSQL);
	//Initialize counter to 0
	$intCounter=0;
	
	//Iterate through each year to get the data for that year
	while(odbc_fetch_row($oRsYears))
	{
		//Get the year
		$intYear = odbc_result($oRsYears,"Year");
		//Generate the <dataset> string for this year.
		$strDataSet = $strDataSet . "<dataset seriesName='" . $intYear . "' color='" . $strColor[$intCounter] . "' showValues='0'>" . chr(13);		
		//Generate the SQL Query to retrieve data for this year.
		$strSQL = "SELECT Country, SUM(ExtendedPrice) As Total, COUNT(DISTINCT OrderID) As orderNumber FROM Invoices WHERE Country In ('USA','Germany','Austria','Brazil','France') and DATEPART(yy,OrderDate)=" . $intYear . " GROUP BY Country ORDER BY Country";
		//Retrieve the recordset
		$oRs=odbc_exec($sqlconnect, $strSQL);
		while(odbc_fetch_row($oRs))	{    
			//Now generate the <set> elements for this dataset in the format <set value='xxxx' />
			$strDataSet = $strDataSet . "<set value='" . odbc_result($oRs,"Total") . "' />" . chr(13);
			}
		$strDataSet = $strDataSet . "</dataset>" . chr(13);
		//Increment the counter
		$intCounter=$intCounter + 1;
	}
	//Generate the XML document by concatenating the strings we've generated. Also, close the <graph> element.	
	$strXMLData = $strXMLData . $strCategories . $strDataSet . "</graph>";

	//Write the XML data to output stream
	echo($strXMLData); 
?>