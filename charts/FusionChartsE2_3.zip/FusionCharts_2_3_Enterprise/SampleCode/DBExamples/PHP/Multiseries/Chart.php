<HTML>
<HEAD>
<TITLE>FusionCharts</TITLE>
<LINK REL='Stylesheet' HREF='../Style.css'>
</HEAD>
<table width="500" border="0" cellpadding="2" cellspacing="0" class="tableWithBorder" align='center'>  
  <tr> 
    <td valign="top">
    <table width="98%" border="0" cellspacing="0" cellpadding="2" align='center'>
        <tr> 
                <td>
                <div align="center" class="text"> 
					<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"  codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" WIDTH="450" HEIGHT="300" id="FusionCharts" ALIGN="">
					<PARAM NAME="FlashVars" value="&dataURL=Data.php">
					<PARAM NAME=movie VALUE="../../../Charts/FC_2_3_MSColumn3D.swf?chartWidth=450&chartHeight=300">
					<PARAM NAME=quality VALUE=high>
					<PARAM NAME=bgcolor VALUE=#FFFFFF>
					<EMBED src="../../../Charts/FC_2_3_MSColumn3D.swf?chartWidth=450&chartHeight=300" FlashVars="&dataURL=Data.php" quality=high bgcolor=#FFFFFF WIDTH="450" HEIGHT="300" NAME="FusionCharts" ALIGN="" TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer"></EMBED>
					</OBJECT>
				</div>
				</td>
         </tr>               
    </table>
    </td>
  </tr>
</table>
<p align="center" class="text">&copy;All Rights Reserved - InfoSoft Global Private Limited - 2005 - <a href="http://www.InfoSoftGlobal.com" target="_blank">www.InfoSoftGlobal.com</a></p>
</BODY></html>
