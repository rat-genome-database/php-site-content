You'll need to change the database connection strings present in Connection_ini.php to view this example.
