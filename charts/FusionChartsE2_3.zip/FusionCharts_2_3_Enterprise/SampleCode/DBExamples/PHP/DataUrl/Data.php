<?php
	//Include connection and colors file
	include '../FC_Colors.php';
	include '../Connection_ini.php';
	
	//Connect to the ODBC Source
	$sqlconnect=odbc_connect($dsn,$username,$password);
	
	//strSQL		- String variable to contain the SQL query	
	$strSQL="SELECT TOP 5 Country, SUM(ExtendedPrice) As Total, COUNT(DISTINCT OrderID) As orderNumber	FROM Invoices WHERE YEAR(OrderDate)=" . $_GET["year"] . " GROUP BY Country ORDER BY SUM(ExtendedPrice) DESC";	
	
	//strXMLDataData - String variable to contain the entire XML data document for the chart
	//Initialize the <graph> element.
	$strXMLData = "<graph caption='Top 5 Countries for the Year " . $_GET["year"] . "' shownames='1' showvalues='0' decimalPrecision='0' numberPrefix='$'>" . chr(13);
	
	$intCounter=0;
	//Get the recordset
	$oRs=odbc_exec($sqlconnect, $strSQL);
	
	//Iterate through each row to get the data
	while(odbc_fetch_row($oRs))	{
		//Append the value in format <set name='...' value='...' color='...' />
		$strXMLData = $strXMLData . "<set name='" . odbc_result($oRs,"Country") . "' color='" . $strColor[$intCounter] . "' value='" . odbc_result($oRs,"Total") . "'/>" . chr(13); 
		//Increment the counter
		$intCounter=$intCounter+1;
	}
	odbc_close($sqlconnect);
	
	//Entire XML - concatenation
	$strXMLData = $strXMLData . "</graph>";
	
	//Write the XML data to output stream
	echo trim($strXMLData);
?>
