<HTML>
<HEAD>
<TITLE>FusionCharts</TITLE>
<LINK REL='Stylesheet' HREF='../Style.css'>
</HEAD>
<?php	
	//Include connection and colors file
	include '../Connection_ini.php';
	include '../FC_Colors.php';
		
	//Connect to the ODBC Source
	$sqlconnect=odbc_connect($dsn,$username,$password);
	
	//Generate the query to get a list of unique years
	$strSQL="SELECT DISTINCT YEAR(OrderDate) As Year FROM Orders ORDER BY 1";

	//Get the list of years
	$oRsYears=odbc_exec($sqlconnect, $strSQL);
	
	//If an year has been selected	
	if ($_POST)	{
		$intYear = $_POST['year'];
	}
	else {
		//By default select the last year.
		while(odbc_fetch_row($oRsYears)){
			$intYear = odbc_result($oRsYears,"Year");
		}		
	}	
	//Define dataURL
	$strDataURL = "Data.php?year=" . $intYear;
	//URL Encode the dataURL - Important Step
	$strDataURL = urlencode($strDataURL);
?>
<table width="500" border="0" cellpadding="2" cellspacing="0" class="tableWithBorder" align='center'>
  <tr> 
    <td colspan="3" class="trdark"><div align="center"><span class="textboldlight">FusionCharts</span></div></td>
  </tr>
  <form action="Chart.php" method="post">
  <tr> 
    <td colspan="3" class="text" align="center">Please select the year for which you want to see the chart: 
      <SELECT name='year' class='select' onChange="this.form.submit();">
		<?
		//Get back to start position
		$oRsYears=odbc_exec($sqlconnect, $strSQL);
		while(odbc_fetch_row($oRsYears)){
			echo("<option value='" . odbc_result($oRsYears,"Year") . "'");
			if (odbc_result($oRsYears,"Year")==$intYear){
				echo(" selected");
			}			
			echo(" >" . odbc_result($oRsYears,"Year"));			
		}
		?>
		
      </SELECT>
	 </td>
  </tr>
  </form>
  <tr> 
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr> 
    <td valign="top">
    <table width="98%" border="0" cellspacing="0" cellpadding="2" align='center'>
        <tr> 
                <td>
                <div align="center" class="text"> 
					<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"  codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" WIDTH="450" HEIGHT="300" id="FusionCharts" ALIGN="">
					<PARAM NAME="FlashVars" value="&dataURL=<?=$strDataURL?>">
					<PARAM NAME=movie VALUE="../../../Charts/FC_2_3_Column3D.swf?chartWidth=450&chartHeight=300">
					<PARAM NAME=quality VALUE=high>
					<PARAM NAME=bgcolor VALUE=#FFFFFF>
					<EMBED src="../../../Charts/FC_2_3_Column3D.swf?chartWidth=450&chartHeight=300" FlashVars="&dataURL=<?=$strDataURL?>" quality=high bgcolor=#FFFFFF WIDTH="450" HEIGHT="300" NAME="FusionCharts" ALIGN="" TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer"></EMBED>
					</OBJECT>
				</div>
				</td>
         </tr>               
    </table>
    </td>
  </tr>
</table>
<p align="center" class="text">&copy;All Rights Reserved - InfoSoft Global Private Limited - 2005 - <a href="http://www.InfoSoftGlobal.com" target="_blank">www.InfoSoftGlobal.com</a></p>
</BODY></html>