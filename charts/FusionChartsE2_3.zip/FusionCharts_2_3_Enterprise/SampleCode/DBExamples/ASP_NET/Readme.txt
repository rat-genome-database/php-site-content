You'll need to change the database connection strings present in Web.Config to view this example.
